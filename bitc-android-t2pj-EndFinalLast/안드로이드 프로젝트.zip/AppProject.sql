-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 58.239.58.243    Database: java405_team2_mobile
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `map`
--

DROP TABLE IF EXISTS `map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `map` (
  `map_id` bigint NOT NULL AUTO_INCREMENT,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `pin_name` varchar(255) DEFAULT NULL,
  `trav_id` bigint DEFAULT NULL,
  `pin_color` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`map_id`)
) ENGINE=InnoDB AUTO_INCREMENT=166 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `map`
--

LOCK TABLES `map` WRITE;
/*!40000 ALTER TABLE `map` DISABLE KEYS */;
INSERT INTO `map` VALUES (82,'35.14515330003152','129.05364453792572','마젠타? 자주색? 몰라2',24,'Purple'),(145,'35.14700710863177','129.06480956822634','금융센터 자리2',24,'Blue'),(146,'35.15265819535148','129.0655780211091','카페 엄청 많음3',24,'Cyan'),(152,'35.16747624707698','129.05588921159506','시민',24,'Red'),(157,'35.15622371015308','129.05632473528385','롯데백화점',24,'Orange'),(158,'35.15667654977716','129.06315632164478','이자리는 뭐야',24,'Yellow'),(159,'35.15696765963299','129.0765254572034','황령산',24,'Magenta'),(161,'35.1509988769791','129.04729910194874','아무거나2',24,'Red'),(164,'35.15414094436504','129.05813053250313','테스트',24,'Magenta'),(165,'35.16355619999999','129.0618099','부전역',24,'Cyan');
/*!40000 ALTER TABLE `map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `memo`
--

DROP TABLE IF EXISTS `memo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `memo` (
  `memo_id` bigint NOT NULL AUTO_INCREMENT,
  `trav_id` bigint DEFAULT NULL,
  `memo_content` varchar(255) DEFAULT NULL,
  `memo_create_date` varchar(255) DEFAULT NULL,
  `memo_title` varchar(255) DEFAULT NULL,
  `choice_date` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`memo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `memo`
--

LOCK TABLES `memo` WRITE;
/*!40000 ALTER TABLE `memo` DISABLE KEYS */;
INSERT INTO `memo` VALUES (3,3,'교토에 갔다','2024-09-06 14:21:37','1일차 여행',NULL),(9,19,'맛집 찾았음','2024-09-09 16:27:03','2일차 여행','20240909'),(42,24,'다음엔 더 길게 계획 잡아서 오자','20240910','또 오자	','2024.09.25'),(45,24,'수정','20240914','수정','2024.09.24'),(48,24,'일기','20240920','일기1','2024.09.21');
/*!40000 ALTER TABLE `memo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `money`
--

DROP TABLE IF EXISTS `money`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `money` (
  `money_id` bigint NOT NULL AUTO_INCREMENT,
  `expenses` bigint DEFAULT NULL,
  `money_title` varchar(255) DEFAULT NULL,
  `trav_id` bigint DEFAULT NULL,
  PRIMARY KEY (`money_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `money`
--

LOCK TABLES `money` WRITE;
/*!40000 ALTER TABLE `money` DISABLE KEYS */;
INSERT INTO `money` VALUES (10,100000,'추가2수정',19),(11,50000,'추가3',19),(12,60000,'추가4수정',19),(13,600000,'항공권',25),(14,500000,'교통비',26),(17,150000,'추가3',19),(18,150000,'추가5',19),(19,160000,'추가6',19),(20,150000,'버스비	',24),(21,600000,'숙박비',24),(28,500000,'숙박비2',24);
/*!40000 ALTER TABLE `money` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay`
--

DROP TABLE IF EXISTS `pay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pay` (
  `pay_id` bigint NOT NULL AUTO_INCREMENT,
  `minus_amt` bigint DEFAULT NULL,
  `money_id` bigint DEFAULT NULL,
  `pay_title` varchar(255) DEFAULT NULL,
  `plus_amt` bigint DEFAULT NULL,
  `trav_id` bigint DEFAULT NULL,
  PRIMARY KEY (`pay_id`),
  KEY `FKi9rj56brb56fmmindq2jdvtfl` (`money_id`),
  CONSTRAINT `FKi9rj56brb56fmmindq2jdvtfl` FOREIGN KEY (`money_id`) REFERENCES `money` (`money_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay`
--

LOCK TABLES `pay` WRITE;
/*!40000 ALTER TABLE `pay` DISABLE KEYS */;
INSERT INTO `pay` VALUES (4,0,10,'추가입금',80000,19),(10,0,12,'입금',500000,19),(12,-100000,13,'출발',0,25),(13,-100000,13,'입국',0,25),(17,-5000,13,'지출',0,25),(18,-3600,14,'지하철',0,26),(29,-5000,12,'감자',0,19),(30,-7000,19,'감자2',0,19),(31,-20000,20,'대충	',0,24),(32,0,20,'추가버스비',50000,24),(33,-150000,21,'첫날숙박비',0,24),(35,-80000,28,'첫날',0,24),(36,0,28,'추가숙박비',50000,24);
/*!40000 ALTER TABLE `pay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `photo`
--

DROP TABLE IF EXISTS `photo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `photo` (
  `photo_id` bigint NOT NULL AUTO_INCREMENT,
  `create_date` varchar(255) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `trav_id` bigint DEFAULT NULL,
  PRIMARY KEY (`photo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photo`
--

LOCK TABLES `photo` WRITE;
/*!40000 ALTER TABLE `photo` DISABLE KEYS */;
INSERT INTO `photo` VALUES (6,'20240920','1726796391890_photo_1726823527110.jpg','/fullstack405/kotlin/teamProjectImg\\',24);
/*!40000 ALTER TABLE `photo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `to_do_list`
--

DROP TABLE IF EXISTS `to_do_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `to_do_list` (
  `todo_complete` char(1) NOT NULL,
  `todo_impo` char(1) NOT NULL,
  `todo_id` bigint NOT NULL AUTO_INCREMENT,
  `trav_id` bigint DEFAULT NULL,
  `todo_content` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`todo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `to_do_list`
--

LOCK TABLES `to_do_list` WRITE;
/*!40000 ALTER TABLE `to_do_list` DISABLE KEYS */;
INSERT INTO `to_do_list` VALUES ('N','Y',6,3,'수건챙겨!!'),('N','Y',7,3,'수건챙겨!!,수건챙겨!!'),('N','N',36,0,''),('N','N',37,0,''),('N','N',38,0,''),('N','Y',40,24,'비행기 예매'),('N','N',41,24,'챙겨야 할 짐 목록 찾기'),('Y','N',42,24,'면세 예약'),('N','N',43,19,'투두리스트 첫번째'),('N','N',44,19,'투두리스트 두번째 중요'),('Y','N',65,18,'gohome'),('N','Y',66,18,'bus'),('Y','Y',67,18,'1111'),('N','Y',71,24,'추가1'),('Y','Y',73,24,'추가2'),('Y','Y',74,24,'테스트');
/*!40000 ALTER TABLE `to_do_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `travel`
--

DROP TABLE IF EXISTS `travel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `travel` (
  `trav_complete` char(1) NOT NULL,
  `trav_id` bigint NOT NULL AUTO_INCREMENT,
  `cate` varchar(255) DEFAULT NULL,
  `create_date` varchar(255) DEFAULT NULL,
  `end_date` varchar(255) DEFAULT NULL,
  `start_date` varchar(255) DEFAULT NULL,
  `trav_title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`trav_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `travel`
--

LOCK TABLES `travel` WRITE;
/*!40000 ALTER TABLE `travel` DISABLE KEYS */;
INSERT INTO `travel` VALUES ('N',18,'4','20240909','20240927','20240919','여행1'),('Y',19,'3','20240909','20240918','20240918','여행완1'),('N',24,'1','20240909','20240926','20240918','나혼자 유럽여행'),('N',25,'3','20240910','20241004','20240930','가족여행'),('Y',26,'1','20240912','20240919','20240912','여행완2'),('N',28,'1','20240913','20240930','20240919','여행'),('Y',29,'1','20240919','20240918','20240917','111'),('Y',31,'1','20240920','20240919','20240905','완료테스트'),('Y',33,'1','20240920','20240919','20240918','테스트여행');
/*!40000 ALTER TABLE `travel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'java405_team2_mobile'
--

--
-- Dumping routines for database 'java405_team2_mobile'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-20 13:48:34
